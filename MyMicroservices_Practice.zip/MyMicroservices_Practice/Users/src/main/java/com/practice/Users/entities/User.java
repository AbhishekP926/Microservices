package com.practice.Users.entities;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="CUSTOMER_USER")
public class User {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	private Long oId;
	private String uName;
	private String uPassword;
	private String uEmail;
	private  String urole;
	
	public User() {
		super();
	}
	
	public User(Long oId, String uName, String uPassword, String uEmail,String urole) {
		super();
		this.oId = oId;
		this.uName = uName;
		this.uPassword = uPassword;
		this.uEmail = uEmail;
		this.urole = urole;
	}
	public Long getoId() {
		return oId;
	}
	public void setoId(Long oId) {
		this.oId = oId;
	}
	public String getuName() {
		return uName;
	}
	public void setuName(String uName) {
		this.uName = uName;
	}
	public String getuPassword() {
		return uPassword;
	}
	public void setuPassword(String uPassword) {
		this.uPassword = uPassword;
	}
	public String getuEmail() {
		return uEmail;
	}
	public void setuEmail(String uEmail) {
		this.uEmail = uEmail;
	}
	@Override
	public String toString() {
		return "User [oId=" + oId + ", uName=" + uName + ", uPassword=" + uPassword + ", uEmail=" + uEmail + ", uRole="+ urole+"]";
	}
	public String getUrole() {
		return urole;
	}
	public void setUrole(String urole) {
		this.urole = urole;
	}
	
	
	
	
	
}
