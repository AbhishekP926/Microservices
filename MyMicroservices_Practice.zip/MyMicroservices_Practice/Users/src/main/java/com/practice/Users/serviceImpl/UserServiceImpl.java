package com.practice.Users.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.practice.Users.entities.User;
import com.practice.Users.exceptions.UserException;
import com.practice.Users.repositories.UserRepository;
import com.practice.Users.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository repo;

	@Override
	public User registerUser(User pUser) throws Exception {
	
		Optional<User> user = repo.findByuName(pUser.getuName());
		if(user.isPresent()) {
			throw new UserException("User Name is already exists...User Name : "+user.get().getuName());
		}
		User registerdUser = repo.save(pUser);
		return registerdUser;
	}
	
	
	
	@Override
	public List<User> retrieveAllUsers()  {

		return repo.findAll();
	}

	public UserServiceImpl() {
		super();
	}

	@Override
	public User getUserProfile(String pName, String pPassword) throws UserException {
		// TODO Auto-generated method stub
		if(repo.findByuNameAnduPassword(pName,pPassword)==null) {
			throw new UserException("User Name does not exists...please check the credentials : ");
		}
		return repo.findByuNameAnduPassword(pName,pPassword);
	}

	@Override
	public User updateUserProfile(String pName, String pPassword,User pUser) throws Exception {
		// TODO Auto-generated method stub
//		repo.fingByuNameAnduPassword(pName, pPassword).map(p -> ResponseEntity.ok(new PersonResource(p))).orElseThrow(() -> new UserException("\"User Name does not exists...please check the credentials : \""));
//		repo.fingByuNameAnduPasswor, pPassword)(pName, pPassword).map(p -> ResponseEntity.ok(new PersonResource(p))).orElseThrow(() -> new UserException("\"User Name does not exists...please check the credentials : \""));
//re
//		repo.findById(pUser.getoId()).map(p -> ResponseEntity.ok(HttpStatus.OK)).orElseThrow(() -> new UserException("\"User Name does not exists...please check the credentials : \""));
		if(pUser.getuEmail()!=null && !pUser.getuEmail().isEmpty()) {
		this.getUserProfile(pName, pPassword).setuEmail(pUser.getuEmail());
		}
		repo.save(this.getUserProfile(pName, pPassword));
		return this.getUserProfile(pName, pPassword);
	}
	
	
}
