package com.practice.Users.controllers;

import java.net.URI;
import java.util.HashMap;
import java.util.List;

import org.apache.catalina.filters.AddDefaultCharsetFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.practice.Users.entities.User;
import com.practice.Users.entities.UserEvents;
import com.practice.Users.proxy.EventsProxy;
import com.practice.Users.service.UserService;

@RestController
public class UserController {

	@Autowired
	UserService service;
	
	@Autowired
	EventsProxy proxy;

	@PostMapping(path="/users/addUser")
	public ResponseEntity<Object> createUsers(@RequestBody User pUser) throws Exception{
		User user = service.registerUser(pUser);
//		HashMap<String,String> uriVariables = new HashMap<String,String>();
		URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(user.getuName()).toUri();
		return ResponseEntity.created(location).build();
	} 
	
	
	@GetMapping(path="/users")
	public List<User> getAllUsers(){
		return service.retrieveAllUsers();
	} 
	
	@GetMapping(path="/users/name/{pName}/password/{pPwd}")
	public User getmyProfile(@PathVariable String pName,@PathVariable String pPwd) throws Exception{
		
		return service.getUserProfile(pName,pPwd);
	} 
	
	@PutMapping(path="/users/name/{pName}/password/{pPwd}")
	public ResponseEntity<User> updateUserProfile(@PathVariable String pName,@PathVariable String pPwd,@RequestBody User pUser) throws Exception{
		
		User user = service.updateUserProfile(pName,pPwd,pUser);
//		HashMap<String,String> uriVariables = new HashMap<String,String>();
//		URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(user.getuName()).toUri();
		URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(user.getuName()).toUri();
		return ResponseEntity.created(location).body(user);
		
		
	} 
	@GetMapping(path="/users/events/{pUserId}")
	public UserEvents getEventsForUser(@PathVariable long pUserId){
		
		UserEvents response = proxy.getEventsForUser(pUserId);
		return response;
	} 
	
}
