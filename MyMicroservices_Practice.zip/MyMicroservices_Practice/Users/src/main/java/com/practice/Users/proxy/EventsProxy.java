package com.practice.Users.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.practice.Users.entities.UserEvents;



@FeignClient("Events-Module")
@RibbonClient("Events-Module")
public interface EventsProxy {

	@GetMapping(path="/Events/forUser/{userId}")
	public UserEvents getEventsForUser(@PathVariable("userId") long pUserId);
		
}
