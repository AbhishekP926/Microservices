package com.practice.Users.entities;

import java.util.Date;

public class EventTimes {

    private Date sessionStartDate;
	
	private Date sessionEndDate;
	
	private Integer noOfDays;
	
	private String startTime;
	
	private String endTime;
	
	public EventTimes(Date sessionStartDate, Date sessionEndDate, Integer noOfDays, String startTime, String endTime) {
		super();
		this.sessionStartDate = sessionStartDate;
		this.sessionEndDate = sessionEndDate;
		this.noOfDays = noOfDays;
		this.startTime = startTime;
		this.endTime = endTime;
	}

	/**
	 * @return the sessionStartDate
	 */
	public Date getSessionStartDate() {
		return sessionStartDate;
	}

	/**
	 * @param sessionStartDate the sessionStartDate to set
	 */
	public void setSessionStartDate(Date sessionStartDate) {
		this.sessionStartDate = sessionStartDate;
	}

	/**
	 * @return the sessionEndDate
	 */
	public Date getSessionEndDate() {
		return sessionEndDate;
	}

	/**
	 * @param sessionEndDate the sessionEndDate to set
	 */
	public void setSessionEndDate(Date sessionEndDate) {
		this.sessionEndDate = sessionEndDate;
	}

	/**
	 * @return the noOfDays
	 */
	public Integer getNoOfDays() {
		return noOfDays;
	}

	/**
	 * @param noOfDays the noOfDays to set
	 */
	public void setNoOfDays(Integer noOfDays) {
		this.noOfDays = noOfDays;
	}

	/**
	 * @return the startTime
	 */
	public String getStartTime() {
		return startTime;
	}

	/**
	 * @param startTime the startTime to set
	 */
	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	/**
	 * @return the endTime
	 */
	public String getEndTime() {
		return endTime;
	}

	/**
	 * @param endTime the endTime to set
	 */
	public void setEndTime(String endTime) {
		this.endTime = endTime;
	}
	
}
