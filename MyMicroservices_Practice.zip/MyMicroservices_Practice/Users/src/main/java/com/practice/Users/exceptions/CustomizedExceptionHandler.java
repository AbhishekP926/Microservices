package com.practice.Users.exceptions;

import java.util.Date;

import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;




@ControllerAdvice    //This annotation used when you want to implement a behaviour(Class) aross all controllers in the project//
@RestController
public class CustomizedExceptionHandler extends ResponseEntityExceptionHandler {

	@ExceptionHandler(UserException.class)
	public final ResponseEntity<Object> handleAllException(Exception ex, WebRequest request)  {
		
		ExceptionResponseStructure exception = new ExceptionResponseStructure(new Date(),request.getDescription(false),ex.getMessage());
	   return new ResponseEntity(exception, HttpStatus.BAD_REQUEST);
	}
	
	/*@Override
	protected ResponseEntity<Object> handleMethodArgumentNotValid(
			MethodArgumentNotValidException ex, HttpHeaders headers, HttpStatus status, WebRequest request) {

		ExceptionResponseStructure exception = new ExceptionResponseStructure(new Date(),ex.getBindingResult().toString(),"Not a valid request");
		   return new ResponseEntity(exception, HttpStatus.BAD_REQUEST);
	}*/
	
}
