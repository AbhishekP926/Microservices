package com.practice.Users.repositories;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.practice.Users.entities.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	
	public Optional<User> findByuName(String pUname);
	
	@Query("select u from User u where u.uName=?1 and u.uPassword=?2")
	public User findByuNameAnduPassword(String pUname,String pPassword);
}

