package com.practice.Users.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.practice.Users.entities.User;


public interface UserService {

	public User registerUser(User pUser) throws Exception;
	
	public List<User> retrieveAllUsers();
	
	public User getUserProfile(String pName,String pPassword) throws Exception;
	
	public User updateUserProfile(String pName, String pPassword,User pUser) throws Exception;
	
}
