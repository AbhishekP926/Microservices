package com.practice.Users.entities;



public class UserEvents {

    private Long oId;
	
    private String eventName;
	
	private String eventBy;
	
	private Long userId;
	
	private EventTimes timings;

	/**
	 * @param oId
	 * @param eventName
	 * @param eventBy
	 * @param userId
	 * @param timings
	 */
	public UserEvents(Long oId, String eventName, String eventBy, Long userId, EventTimes timings) {
		super();
		this.oId = oId;
		this.eventName = eventName;
		this.eventBy = eventBy;
		this.userId = userId;
		this.timings = timings;
	}

	/**
	 * @return the oId
	 */
	public Long getoId() {
		return oId;
	}

	/**
	 * @param oId the oId to set
	 */
	public void setoId(Long oId) {
		this.oId = oId;
	}

	/**
	 * @return the eventName
	 */
	public String getEventName() {
		return eventName;
	}

	/**
	 * @param eventName the eventName to set
	 */
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	/**
	 * @return the eventBy
	 */
	public String getEventBy() {
		return eventBy;
	}

	/**
	 * @param eventBy the eventBy to set
	 */
	public void setEventBy(String eventBy) {
		this.eventBy = eventBy;
	}

	/**
	 * @return the userId
	 */
	public Long getUserId() {
		return userId;
	}

	/**
	 * @param userId the userId to set
	 */
	public void setUserId(Long userId) {
		this.userId = userId;
	}

	/**
	 * @return the timings
	 */
	public EventTimes getTimings() {
		return timings;
	}

	/**
	 * @param timings the timings to set
	 */
	public void setTimings(EventTimes timings) {
		this.timings = timings;
	}
	
	
}
