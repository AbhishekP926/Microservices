/**
 * 
 */
package com.example.morgage.Products.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.example.morgage.Products.dto.ProductsRequest;
import com.example.morgage.Products.entities.Products;

/**
 * @author PendyalA
 *
 */
@Repository
public interface ProductsDao extends JpaRepository<Products, Long> {
	
	@Query("select products from Products products where loanType=:#{#request.loanType} And eligibleLoanAmount <= :#{#request.annualIncome}")
	List<Products> fetchMortgageProducts(@Param("request") ProductsRequest request);
	

}
