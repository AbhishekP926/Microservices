/**
 * 
 */
package com.example.morgage.Products.serviceImpl;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.morgage.Products.dao.ProductsDao;
import com.example.morgage.Products.dto.ProductsDto;
import com.example.morgage.Products.dto.ProductsRequest;
import com.example.morgage.Products.service.ProductsService;

/**
 * @author PendyalA
 *
 */
@Service
public class ProductsServiceImpl implements ProductsService{
	
	@Autowired
	ProductsDao repo;
	ModelMapper modelMapper = new ModelMapper();
	public static final BigDecimal ONE_HUNDRED = new BigDecimal(100);
	public static final BigDecimal MAXMIMUM_LOAN_ELIGIBILITY_FACTOR = new BigDecimal(90);


	@Override
	public List<ProductsDto> fetchAllProducts() {
//		repo.findAll().stream().map(source -> modelMapper.map(source, ProductsDto.class)).collect(Collectors.toList());
		// TODO Auto-generated method stub
		return 	repo.findAll().stream().map(source -> modelMapper.map(source, ProductsDto.class)).collect(Collectors.toList());

	}

	@Override
	public List<ProductsDto> fetchMortgageProducts(ProductsRequest request) {
		// TODO Auto-generated method stub
		request.setAnnualIncome(request.getAnnualIncome().multiply(MAXMIMUM_LOAN_ELIGIBILITY_FACTOR).divide(ONE_HUNDRED));
		return repo.fetchMortgageProducts(request).stream().map(source -> modelMapper.map(source, ProductsDto.class)).collect(Collectors.toList());
	}

}
