/**
 * 
 */
package com.example.morgage.Products.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.morgage.Products.dto.ProductsDto;
import com.example.morgage.Products.dto.ProductsRequest;
import com.example.morgage.Products.service.ProductsService;


/**
 * @author PendyalA
 *
 */
@RestController
@RequestMapping("/loan")
public class ProductsController {
	
	@Autowired
	ProductsService service;

	@GetMapping("/allproducts")
	public List<ProductsDto> fetchAllProducts(){
		return service.fetchAllProducts();
	}
	@GetMapping("/eligibleproducts")
	public List<ProductsDto> fetchMortgageProducts(@RequestBody ProductsRequest request ){
		return service.fetchMortgageProducts(request);
	}
	
}
