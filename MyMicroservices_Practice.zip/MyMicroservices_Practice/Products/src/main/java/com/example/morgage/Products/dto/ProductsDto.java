/**
 * 
 */
package com.example.morgage.Products.dto;

import java.math.BigDecimal;

/**
 * @author PendyalA
 *
 */
public class ProductsDto {
	
	private Long oid;
	private String offerName;
	private BigDecimal eligibleLoanAmount;
	private String loanType;
	private BigDecimal offerFee;
	private String interestRate;
	
	
	public ProductsDto() {
		super();
	}
	
	/**
	 * @param oid
	 * @param offerName
	 * @param eligibleLoanAmount
	 * @param loanType
	 * @param offerFee
	 * @param interestRate
	 */
	public ProductsDto(Long oid, String offerName, BigDecimal eligibleLoanAmount, String loanType, BigDecimal offerFee,
			String interestRate) {
		super();
		this.oid = oid;
		this.offerName = offerName;
		this.eligibleLoanAmount = eligibleLoanAmount;
		this.loanType = loanType;
		this.offerFee = offerFee;
		this.interestRate = interestRate;
	}

	/**
	 * @return the oid
	 */
	public Long getOid() {
		return oid;
	}

	/**
	 * @param oid the oid to set
	 */
	public void setOid(Long oid) {
		this.oid = oid;
	}

	/**
	 * @return the offerName
	 */
	public String getOfferName() {
		return offerName;
	}

	/**
	 * @param offerName the offerName to set
	 */
	public void setOfferName(String offerName) {
		this.offerName = offerName;
	}

	/**
	 * @return the eligibleLoanAmount
	 */
	public BigDecimal getEligibleLoanAmount() {
		return eligibleLoanAmount;
	}

	/**
	 * @param eligibleLoanAmount the eligibleLoanAmount to set
	 */
	public void setEligibleLoanAmount(BigDecimal eligibleLoanAmount) {
		this.eligibleLoanAmount = eligibleLoanAmount;
	}

	/**
	 * @return the loanType
	 */
	public String getLoanType() {
		return loanType;
	}

	/**
	 * @param loanType the loanType to set
	 */
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	/**
	 * @return the offerFee
	 */
	public BigDecimal getOfferFee() {
		return offerFee;
	}

	/**
	 * @param offerFee the offerFee to set
	 */
	public void setOfferFee(BigDecimal offerFee) {
		this.offerFee = offerFee;
	}

	/**
	 * @return the interestRate
	 */
	public String getInterestRate() {
		return interestRate;
	}

	/**
	 * @param interestRate the interestRate to set
	 */
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	
	
}
