/**
 * 
 */
package com.example.morgage.Products.service;

import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.morgage.Products.dto.ProductsDto;
import com.example.morgage.Products.dto.ProductsRequest;

/**
 * @author PendyalA
 *
 */
@Service
public interface ProductsService {

	public List<ProductsDto> fetchAllProducts();
	
	public List<ProductsDto> fetchMortgageProducts(ProductsRequest request );
	
	
}
