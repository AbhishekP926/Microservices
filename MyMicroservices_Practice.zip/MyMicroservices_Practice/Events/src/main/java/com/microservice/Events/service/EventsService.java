package com.microservice.Events.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.microservice.Events.Dao.Events;

@Service
public interface EventsService {

	public Events createEvent(Events pEvent);
	
	public List<Events> fetchEventsByUser(Long pUserId);
	
	public List<Events> displayAllEvents();
	
	public List<Events> displayExpiredEventsForUser(Long pUserId);
	
	public List<Events> displayAvilableEventsForUser(Long pUserId);
	
	
}
