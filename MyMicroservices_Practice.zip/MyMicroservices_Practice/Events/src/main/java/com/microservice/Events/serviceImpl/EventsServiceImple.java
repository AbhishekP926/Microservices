package com.microservice.Events.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.microservice.Events.Dao.Events;
import com.microservice.Events.repository.EventsRepo;
import com.microservice.Events.service.EventsService;

@Service
public class EventsServiceImple implements EventsService {

	@Autowired
	private EventsRepo repo;
	
	@Override
	public Events createEvent(Events pEvent) {
		// TODO Auto-generated method stub
	     
		return repo.save(pEvent);
	}

	@Override
	public List<Events> fetchEventsByUser(Long pUserId) {
		// TODO Auto-generated method stub
		Optional<List<Events>> events = repo.findByuserId(pUserId);
        System.out.println(events.map(p->p.stream().count()));
		return events.get();
	}

	@Override
	public List<Events> displayAllEvents() {
		// TODO Auto-generated method stub
		return repo.findAll();
	}

	@Override
	public List<Events> displayExpiredEventsForUser(Long pUserId) {
		// TODO Auto-generated method stub
		
		return repo.findExpiredEventsForUser(pUserId);
	}

	@Override
	public List<Events> displayAvilableEventsForUser(Long pUserId) {
		// TODO Auto-generated method stub
		return repo.findAvilableEventsForUser(pUserId);
	}

}
