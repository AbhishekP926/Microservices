/**
 * 
 */
package com.microservice.Events.controller;

import java.net.URI;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.microservice.Events.Dao.Events;
import com.microservice.Events.service.EventsService;

/**
 * @author PendyalA
 *
 */
@RestController
@RequestMapping(value="/Events")
public class EventsController {

	@Autowired
	private EventsService service;
	
	@PostMapping(path="/addEvents")
	public ResponseEntity<Events> createEvent(@RequestBody Events pEvent){
		
	     Events createdEvent = service.createEvent(pEvent);
	     URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(createdEvent.getEventName()).toUri();
			return ResponseEntity.created(location).build();
		
		
	}
	@GetMapping(path="/showAll")
	public List<Events> displayAllEvents(){
//	     URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(createdEvent.getEventName()).toUri();
			return service.displayAllEvents();
		
		
	}
	
	@GetMapping(path="forUser/{userId}")
	public List<Events> fetchEventsByUser(@PathVariable Long userId){
//	     URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(createdEvent.getEventName()).toUri();
			return service.displayAllEvents().stream().collect(Collectors.toList());
		
		
	}
	
	@GetMapping(path="expiredEventsforUser/{userId}")
	public List<Events> fetchExpiredEventsByUser(@PathVariable Long userId){
//	     URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(createdEvent.getEventName()).toUri();
			return service.displayExpiredEventsForUser(userId).stream().collect(Collectors.toList());
		
		
	}
	
	@GetMapping(path="availableEventsforUser/{userId}")
	public List<Events> fetchAvailableEventsByUser(@PathVariable Long userId){
//	     URI location =  ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}").buildAndExpand(createdEvent.getEventName()).toUri();
			return service.displayAvilableEventsForUser(userId).stream().collect(Collectors.toList());
		
		
	}
	
	
}
