/**
 * 
 */
package com.microservice.Events.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.microservice.Events.Dao.Events;

/**
 * @author PendyalA
 *
 */
@Repository
public interface EventsRepo extends JpaRepository<Events, Long> {
	
	public Optional<List<Events>> findByuserId(Long pUserId);
	
	
	@Query("select e from Events e where userID=?1 And e.timings.sessionEndDate < trunc(sysdate)")
	public List<Events> findExpiredEventsForUser(Long pUserId);
	
	@Query("select e from Events e where userID=?1 And e.timings.sessionStartDate > trunc(sysdate)")
	public List<Events> findAvilableEventsForUser(Long pUserId);
	

}
