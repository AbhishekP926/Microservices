/**
 * 
 */
package com.example.morgage.Customer.entities;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.Lob;
import javax.persistence.ManyToOne;
import javax.persistence.Transient;

/**
 * @author PendyalA
 *
 */
@Entity
public class DBFile {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private long oid;
	@Transient
	private Integer fileNumber;
	private String fileName;
	@Lob
	private byte[] data;
	private String fileType;
	private Long fileMemory;
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name = "customerId")
	})
	private CustomerDetails customerDetails;
	
	public DBFile() {
		super();
	}
	/**
	 * @param oid
	 * @param fileNumber
	 * @param fileName
	 * @param data
	 * @param fileType
	 * @param fileMemory
	 */
	public DBFile(long oid, Integer fileNumber, String fileName, byte[] data, String fileType, Long fileMemory) {
		super();
		this.oid = oid;
		this.fileNumber = fileNumber;
		this.fileName = fileName;
		this.data = data;
		this.fileType = fileType;
		this.fileMemory = fileMemory;
	}
	/**
	 * @return the oid
	 */
	public long getOid() {
		return oid;
	}
	/**
	 * @param oid the oid to set
	 */
	public void setOid(long oid) {
		this.oid = oid;
	}
	/**
	 * @return the fileNumber
	 */
	public Integer getFileNumber() {
		return fileNumber;
	}
	/**
	 * @param fileNumber the fileNumber to set
	 */
	public void setFileNumber(Integer fileNumber) {
		this.fileNumber = fileNumber;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the fileMemory
	 */
	public Long getFileMemory() {
		return fileMemory;
	}
	/**
	 * @param fileMemory the fileMemory to set
	 */
	public void setFileMemory(Long fileMemory) {
		this.fileMemory = fileMemory;
	}
	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}
	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}
	
	
	
	
	
}
