/**
 * 
 */
package com.example.morgage.Customer.proxy;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.morgage.Customer.entities.CustomerDetails;



/**
 * @author PendyalA
 *
 */
@FeignClient(name = "National-Data")
@RibbonClient(name = "National-Data")
public interface CustomerNationalDataProxy {

	@GetMapping(path="ndb/users/{mobilenumber}")
	public CustomerDetails fetchUsersData(@PathVariable("mobilenumber") String mobilenumber);

	
}
