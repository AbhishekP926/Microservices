/**
 * 
 */
package com.example.morgage.Customer.exception;

/**
 * @author PendyalA
 *
 */
public class FileStorageException extends Exception {

	private String message;

	/**
	 * @param message
	 */
	public FileStorageException(String message) {
		super();
		this.message = message;
	}

	/**
	 * @return the message
	 */
	public String getMessage() {
		return message;
	}

	/**
	 * @param message the message to set
	 */
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
}
