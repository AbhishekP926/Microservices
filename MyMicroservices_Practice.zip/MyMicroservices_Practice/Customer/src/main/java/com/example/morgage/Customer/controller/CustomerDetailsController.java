/**
 * 
 */
package com.example.morgage.Customer.controller;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

import javax.ws.rs.QueryParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.morgage.Customer.Dto.ProductsDto;
import com.example.morgage.Customer.Dto.ProductsRequest;
import com.example.morgage.Customer.entities.CustomerAddress;
import com.example.morgage.Customer.entities.CustomerDetails;
import com.example.morgage.Customer.entities.DBFile;
import com.example.morgage.Customer.proxy.CustomerNationalDataProxy;
import com.example.morgage.Customer.proxy.ProductsProxy;
import com.example.morgage.Customer.service.CustomerDetailsService;
import com.google.common.net.HttpHeaders;

/**
 * @author PendyalA
 *
 */
@RestController
public class CustomerDetailsController {
	
	@Autowired
	CustomerDetailsService service;
	
	@Autowired
	CustomerNationalDataProxy proxy;
	
//	@Autowired
//	ProductsProxy proxy1;

	/**
	 * @author PendyalA
	 * Below method is responsible for retrieval of Mortgage Products details based on UserInputs
	 *
	 */
	@GetMapping(path="/UnboxProducts")
	public List<ProductsDto> UnboxProducts(@RequestBody ProductsRequest productsRequest) {
//		System.out.println(service.UnboxProducts(productsRequest));
		return service.UnboxProducts(productsRequest);
	}
	
//	@GetMapping(path="/UnboxAllProducts")
//	public List<ProductsDto> UnboxAllProducts() {
//		return proxy1.fetchAllProducts();
//	}
	
	/**
	 * @author PendyalA
	 *
	 *Below method is responsible for register the customer. If user checks the useAadhar check box this api hits the service and gets the Aadhar details.
	 */
	@PostMapping(path="/registerCustomer")
	public ResponseEntity<CustomerDetails> registerCustomer(@QueryParam("useAadhar") boolean useAadhar, @RequestBody CustomerDetails pCustomerDetails) {
		
		CustomerDetails aCustomerDetails;
		if(useAadhar = true) {
			//National Data service API call
			 aCustomerDetails = proxy.fetchUsersData(pCustomerDetails.getcNumber());
			pCustomerDetails.setAddress(aCustomerDetails.getAddress());
		}
		aCustomerDetails = service.registerCustomer(pCustomerDetails);
		Resource resource = new Resource(aCustomerDetails);

		  ControllerLinkBuilder linkTo = linkTo(methodOn(this.getClass()).retrieveAllStudents());

		  resource.add(linkTo.withRel("all-students"));

		return ResponseEntity.status(HttpStatus.CREATED).body(service.registerCustomer(pCustomerDetails));
	}
	
	
	@PutMapping(path="/UpdateAddressDetails/cMobileNumber/{mobileNumber}")
	public ResponseEntity<CustomerDetails> UpdateAddressDetails(@PathVariable("mobileNumber") String pNumber, @RequestBody CustomerAddress pCustomerAddress) {
		return ResponseEntity.status(HttpStatus.OK).body(service.UpdateAddressDetails(pNumber,pCustomerAddress));
	}
	
	
	@PutMapping(path="/uploadDocument/mobileNumber/{mobileNumber}")
	public void uploadDocument(@PathVariable("mobileNumber") String pNumber,@RequestParam("file") MultipartFile file) throws Exception {
		
		service.saveDocument(pNumber,file);
	}
	
	
	
	@GetMapping(path="/download/{mobileNumber}/fileName/{filename}")
	public ResponseEntity<Resource> downloadFile(@PathVariable String mobileNumber, @PathVariable String fileName){
		
		Optional<DBFile> file  = service.getDetailsByNumber(mobileNumber).getFile().stream().filter(p->p.getFileName().equalsIgnoreCase(fileName)).findFirst();
		
		return ResponseEntity.ok().contentType(MediaType.parseMediaType(file.get().getFileType())).
				header(HttpHeaders.CONTENT_DISPOSITION, "attachment;fileName=sampletestFile").
				body(new ByteArrayResource(file.get().getData()));
	}
}
