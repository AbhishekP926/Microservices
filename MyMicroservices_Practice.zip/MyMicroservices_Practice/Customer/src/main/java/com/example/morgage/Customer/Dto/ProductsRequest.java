/**
 * 
 */
package com.example.morgage.Customer.Dto;

import java.math.BigDecimal;

/**
 * @author PendyalA
 *
 */
public class ProductsRequest {

	
	private BigDecimal annualIncome;
	private BigDecimal requiredLoanAmount;
	private int noOfYeasLoanOpted;
	private String city;
	private String cNumber;
	private String loanType;
	/**
	 * @return the loanType
	 */
	public String getLoanType() {
		return loanType;
	}
	/**
	 * @param loanType the loanType to set
	 */
	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}
	/**
	 * @return the annualIncome
	 */
	public BigDecimal getAnnualIncome() {
		return annualIncome;
	}
	/**
	 * @param annualIncome the annualIncome to set
	 */
	public void setAnnualIncome(BigDecimal annualIncome) {
		this.annualIncome = annualIncome;
	}
	/**
	 * @return the requiredLoanAmount
	 */
	public BigDecimal getRequiredLoanAmount() {
		return requiredLoanAmount;
	}
	/**
	 * @param requiredLoanAmount the requiredLoanAmount to set
	 */
	public void setRequiredLoanAmount(BigDecimal requiredLoanAmount) {
		this.requiredLoanAmount = requiredLoanAmount;
	}
	/**
	 * @return the noOfYeasLoanOpted
	 */
	public int getNoOfYeasLoanOpted() {
		return noOfYeasLoanOpted;
	}
	/**
	 * @param noOfYeasLoanOpted the noOfYeasLoanOpted to set
	 */
	public void setNoOfYeasLoanOpted(int noOfYeasLoanOpted) {
		this.noOfYeasLoanOpted = noOfYeasLoanOpted;
	}
	/**
	 * @return the city
	 */
	public String getCity() {
		return city;
	}
	/**
	 * @param city the city to set
	 */
	public void setCity(String city) {
		this.city = city;
	}
	/**
	 * @return the cNumber
	 */
	public String getcNumber() {
		return cNumber;
	}
	/**
	 * @param cNumber the cNumber to set
	 */
	public void setcNumber(String cNumber) {
		this.cNumber = cNumber;
	}
	
}
