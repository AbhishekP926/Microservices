/**
 * 
 */
package com.example.morgage.Customer.entities;

import java.math.BigDecimal;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinColumns;
import javax.persistence.ManyToOne;

/**
 * @author PendyalA
 *
 */
@Entity
public class CustomerProduct {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long oid;
	private BigDecimal totalAmountTobePaid;
	private BigDecimal loanAmount;
	private String productName;
	private String interestRate;
	@ManyToOne
	@JoinColumns({
		@JoinColumn(name = "customerId")
	})
	private CustomerDetails customerDetails;
	public CustomerProduct() {
		super();
	}
	
	/**
	 * @param oid
	 * @param customerId
	 * @param totalAmountTobePaid
	 * @param productName
	 * @param interestRate
	 */
	public CustomerProduct(Long oid, BigDecimal totalAmountTobePaid,BigDecimal loanAmount, String productName,
			String interestRate) {
		super();
		this.oid = oid;
		this.totalAmountTobePaid = totalAmountTobePaid;
		this.productName = productName;
		this.interestRate = interestRate;
	}
	/**
	 * @return the oid
	 */
	public Long getOid() {
		return oid;
	}
	/**
	 * @param oid the oid to set
	 */
	public void setOid(Long oid) {
		this.oid = oid;
	}
	/**
	 * @return the totalAmountTobePaid
	 */
	public BigDecimal getTotalAmountTobePaid() {
		return totalAmountTobePaid;
	}
	/**
	 * @param totalAmountTobePaid the totalAmountTobePaid to set
	 */
	public void setTotalAmountTobePaid(BigDecimal totalAmountTobePaid) {
		this.totalAmountTobePaid = totalAmountTobePaid;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the interestRate
	 */
	public String getInterestRate() {
		return interestRate;
	}
	/**
	 * @param interestRate the interestRate to set
	 */
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	/**
	 * @return the loanAmount
	 */
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}
	/**
	 * @param loanAmount the loanAmount to set
	 */
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}
	/**
	 * @return the customerDetails
	 */
	public CustomerDetails getCustomerDetails() {
		return customerDetails;
	}
	/**
	 * @param customerDetails the customerDetails to set
	 */
	public void setCustomerDetails(CustomerDetails customerDetails) {
		this.customerDetails = customerDetails;
	}
	
	
	
}
