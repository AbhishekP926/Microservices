package com.example.morgage.Customer.service;


import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.morgage.Customer.Dto.ProductsDto;
import com.example.morgage.Customer.Dto.ProductsRequest;
import com.example.morgage.Customer.entities.CustomerAddress;
import com.example.morgage.Customer.entities.CustomerDetails;

@Service
public interface CustomerDetailsService {

	public List<ProductsDto> UnboxProducts(ProductsRequest productsRequest);
	
	public void saveDocument(String pNumber,MultipartFile file) throws Exception;
	
	public CustomerDetails getDetailsByNumber(String pNumber);
	
	public CustomerDetails registerCustomer(CustomerDetails pCustomerDetails);
	
	public CustomerDetails UpdateAddressDetails(String pNumber,CustomerAddress pCustomerAddress);
	
	
	
}
