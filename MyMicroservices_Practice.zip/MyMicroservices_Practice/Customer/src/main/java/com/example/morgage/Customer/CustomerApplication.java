package com.example.morgage.Customer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.openfeign.EnableFeignClients;

import com.nexmo.client.NexmoClient;
import com.nexmo.client.sms.SmsSubmissionResponse;
import com.nexmo.client.sms.SmsSubmissionResponseMessage;
import com.nexmo.client.sms.messages.TextMessage;

@SpringBootApplication
@EnableFeignClients
@EnableDiscoveryClient
public class CustomerApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerApplication.class, args);
		
//		NexmoClient client = new NexmoClient.Builder()
//				  .apiKey("574605dc")
//				  .apiSecret("vsOB2OmdOVd676rm")
//				  .build();
//
//				String messageText = "Hello Amar!!! your OTP is : 8998";
//				TextMessage message = new TextMessage("Hi Abhishek", "919986354337", messageText);
//
//				SmsSubmissionResponse response = client.getSmsClient().submitMessage(message);
//
//				for (SmsSubmissionResponseMessage responseMessage : response.getMessages()) {
//				    System.out.println(responseMessage);
//				}
		System.out.println("Hello");
	}

}
