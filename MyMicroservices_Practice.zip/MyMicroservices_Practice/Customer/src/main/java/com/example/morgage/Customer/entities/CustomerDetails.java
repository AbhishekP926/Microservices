package com.example.morgage.Customer.entities;


import java.util.List;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.MappedSuperclass;
import javax.persistence.OneToMany;


@Entity
public class CustomerDetails {

	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
	private Long oid;
	private String cName;
	private String cNumber;
	private String cEmail;
	private long annualIncome;
	private int noOfYeasLoanOpted;
	@Embedded
	private CustomerAddress address ;
	
	@OneToMany(mappedBy="customerDetails", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private Set<DBFile> file;
	
	@OneToMany(mappedBy="customerDetails", cascade = CascadeType.ALL, fetch=FetchType.LAZY)
	private List<CustomerProduct> product;
	
	
	
	/**
	 * @return the file
	 */
	public Set<DBFile> getFile() {
		return file;
	}

	/**
	 * @param file the file to set
	 */
	public void setFile(Set<DBFile> file) {
		this.file = file;
	}

	public CustomerDetails() {
		super();
	}
	
	/**
	 * @param oid
	 * @param cName
	 * @param cNumber
	 * @param cEmail
	 * @param annualIncome
	 * @param noOfYeasLoanOpted
	 * @param address
	 * @param data
	 */
	public CustomerDetails(Long oid, String cName, String cNumber, String cEmail, long annualIncome,
			int noOfYeasLoanOpted, CustomerAddress address) {
		super();
		this.oid = oid;
		this.cName = cName;
		this.cNumber = cNumber;
		this.cEmail = cEmail;
		this.annualIncome = annualIncome;
		this.noOfYeasLoanOpted = noOfYeasLoanOpted;
		this.address = address;
	}
	/**
	 * @return the oid
	 */
	public Long getOid() {
		return oid;
	}
	/**
	 * @param oid the oid to set
	 */
	public void setOid(Long oid) {
		this.oid = oid;
	}
	/**
	 * @return the cName
	 */
	public String getcName() {
		return cName;
	}
	/**
	 * @param cName the cName to set
	 */
	public void setcName(String cName) {
		this.cName = cName;
	}
	/**
	 * @return the cNumber
	 */
	public String getcNumber() {
		return cNumber;
	}
	/**
	 * @param cNumber the cNumber to set
	 */
	public void setcNumber(String cNumber) {
		this.cNumber = cNumber;
	}
	/**
	 * @return the cEmail
	 */
	public String getcEmail() {
		return cEmail;
	}
	/**
	 * @param cEmail the cEmail to set
	 */
	public void setcEmail(String cEmail) {
		this.cEmail = cEmail;
	}
	/**
	 * @return the annualIncome
	 */
	public long getAnnualIncome() {
		return annualIncome;
	}
	/**
	 * @param annualIncome the annualIncome to set
	 */
	public void setAnnualIncome(long annualIncome) {
		this.annualIncome = annualIncome;
	}
	/**
	 * @return the noOfYeasLoanOpted
	 */
	public int getNoOfYeasLoanOpted() {
		return noOfYeasLoanOpted;
	}
	/**
	 * @param noOfYeasLoanOpted the noOfYeasLoanOpted to set
	 */
	public void setNoOfYeasLoanOpted(int noOfYeasLoanOpted) {
		this.noOfYeasLoanOpted = noOfYeasLoanOpted;
	}
	/**
	 * @return the address
	 */
	public CustomerAddress getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(CustomerAddress address) {
		this.address = address;
	}

	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "CustomerDetails [oid=" + oid + ", cName=" + cName + ", cNumber=" + cNumber + ", cEmail=" + cEmail
				+ ", annualIncome=" + annualIncome + ", noOfYeasLoanOpted=" + noOfYeasLoanOpted + ", address=" + address
				+ ", file=" + file + "]";
	}
	
	
	
  
	
}
