/**
 * 
 */
package com.example.morgage.Customer.proxy;

import java.util.List;

import org.springframework.cloud.netflix.ribbon.RibbonClient;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.morgage.Customer.Dto.ProductsDto;
import com.example.morgage.Customer.Dto.ProductsRequest;

import feign.Headers;
import feign.Param;

/**
 * @author PendyalA
 *
 */
@FeignClient(name = "Loan-Products",configuration = ProductsConfiguration.class)
@RibbonClient(name = "Loan-Products")
public interface ProductsProxy {

	@GetMapping(path="loan/eligibleproducts")	
	public List<ProductsDto> fetchMortgageProducts(@RequestBody  ProductsRequest request );

	@GetMapping(path="loan/allproducts")
	public List<ProductsDto> fetchAllProducts();

}
