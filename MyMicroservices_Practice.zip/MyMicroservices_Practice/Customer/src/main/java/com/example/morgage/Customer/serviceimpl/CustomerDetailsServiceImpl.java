/**
 * 
 */
package com.example.morgage.Customer.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.multipart.MultipartFile;

import com.example.morgage.Customer.Dto.ProductsDto;
import com.example.morgage.Customer.Dto.ProductsRequest;
import com.example.morgage.Customer.dao.CustomerDetailsDao;
import com.example.morgage.Customer.dao.FilesDao;
import com.example.morgage.Customer.entities.CustomerAddress;
import com.example.morgage.Customer.entities.CustomerDetails;
import com.example.morgage.Customer.entities.DBFile;
import com.example.morgage.Customer.exception.FileStorageException;
import com.example.morgage.Customer.proxy.ProductsProxy;
import com.example.morgage.Customer.service.CustomerDetailsService;

/**
 * @author PendyalA
 *
 */
@Service
public class CustomerDetailsServiceImpl implements CustomerDetailsService {

	
	@Autowired
	CustomerDetailsDao 	customerRepo;
	
	@Autowired
	FilesDao fileRepo;

	@Autowired
	ProductsProxy productsInfoProxy;
	
	
	@Override
	public List<ProductsDto> UnboxProducts(ProductsRequest productsRequest) {
		// TODO Auto-generated method stub
		return productsInfoProxy.fetchMortgageProducts(productsRequest);
	}

	@Override
	public void saveDocument(String pNumber,MultipartFile file) throws Exception {
		// TODO Auto-generated method stub
		String fileName = StringUtils.cleanPath(file.getOriginalFilename());
		CustomerDetails cu = getDetailsByNumber(pNumber);

        try {
            // Check if the file's name contains invalid characters
            if(fileName.contains("..")) {
            	
                throw new FileStorageException("Sorry! Filename contains invalid path sequence " + fileName);
            }
            DBFile customerFile = new DBFile();
            customerFile.setFileName(file.getOriginalFilename());
            customerFile.setFileMemory(file.getSize());
            customerFile.setFileType(file.getContentType());
            customerFile.setData(file.getBytes());
            customerFile.setCustomerDetails(cu);
            fileRepo.save(customerFile);
        } catch (Exception ex) {
            throw new FileStorageException("Could not store file " + fileName + ". Please try again!"+ ex);
        }
	}

	@Override
	public CustomerDetails getDetailsByNumber(String pNumber) {
		// TODO Auto-generated method stub
		if(customerRepo.findBycNumber(pNumber)==null) {
			return null;
		}
		return customerRepo.findBycNumber(pNumber);
	}

	@Override
	public CustomerDetails registerCustomer(CustomerDetails pCustomerDetails) {
		// TODO Auto-generated method stub
		return customerRepo.save(pCustomerDetails);
	}

	@Override
	public CustomerDetails UpdateAddressDetails(String pNumber,CustomerAddress pCustomerAddress) {
		// TODO Auto-generated method stub
		if(getDetailsByNumber(pNumber)==null) {
			return null;
		}
		CustomerDetails customer = getDetailsByNumber(pNumber);
		customer.setAddress(pCustomerAddress);
		return customerRepo.save(customer);
	}

}
