/**
 * 
 */
package com.example.morgage.Customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.morgage.Customer.entities.CustomerDetails;

/**
 * @author PendyalA
 *
 */
@Repository
public interface CustomerDetailsDao extends JpaRepository<CustomerDetails, Long> {

	
	public CustomerDetails findBycNumber(String pNumber);
}
