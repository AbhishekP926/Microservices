/**
 * 
 */
package com.example.morgage.Customer.Dto;

import java.math.BigDecimal;

/**
 * @author PendyalA
 *
 */
public class CustomerProductDto {
	private Long oid;
	private BigDecimal totalAmountTobePaid;
	private BigDecimal loanAmount;
	private String productName;
	private String interestRate;
	private Long customerId;
	/**
	 * @return the oid
	 */
	public Long getOid() {
		return oid;
	}
	/**
	 * @param oid the oid to set
	 */
	public void setOid(Long oid) {
		this.oid = oid;
	}
	/**
	 * @return the totalAmountTobePaid
	 */
	public BigDecimal getTotalAmountTobePaid() {
		return totalAmountTobePaid;
	}
	/**
	 * @param totalAmountTobePaid the totalAmountTobePaid to set
	 */
	public void setTotalAmountTobePaid(BigDecimal totalAmountTobePaid) {
		this.totalAmountTobePaid = totalAmountTobePaid;
	}
	/**
	 * @return the loanAmount
	 */
	public BigDecimal getLoanAmount() {
		return loanAmount;
	}
	/**
	 * @param loanAmount the loanAmount to set
	 */
	public void setLoanAmount(BigDecimal loanAmount) {
		this.loanAmount = loanAmount;
	}
	/**
	 * @return the productName
	 */
	public String getProductName() {
		return productName;
	}
	/**
	 * @param productName the productName to set
	 */
	public void setProductName(String productName) {
		this.productName = productName;
	}
	/**
	 * @return the interestRate
	 */
	public String getInterestRate() {
		return interestRate;
	}
	/**
	 * @param interestRate the interestRate to set
	 */
	public void setInterestRate(String interestRate) {
		this.interestRate = interestRate;
	}
	/**
	 * @return the customerId
	 */
	public Long getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
}
