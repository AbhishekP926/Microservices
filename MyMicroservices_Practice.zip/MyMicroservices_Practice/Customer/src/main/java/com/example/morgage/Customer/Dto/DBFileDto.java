/**
 * 
 */
package com.example.morgage.Customer.Dto;

import javax.persistence.Lob;

/**
 * @author PendyalA
 *
 */
public class DBFileDto {
	private long oid;
	private Integer fileNumber;
	private String fileName;
	@Lob
	private byte[] data;
	private String fileType;
	private Long fileMemory;
	private Long customerId;
	/**
	 * @return the oid
	 */
	public long getOid() {
		return oid;
	}
	/**
	 * @param oid the oid to set
	 */
	public void setOid(long oid) {
		this.oid = oid;
	}
	/**
	 * @return the fileNumber
	 */
	public Integer getFileNumber() {
		return fileNumber;
	}
	/**
	 * @param fileNumber the fileNumber to set
	 */
	public void setFileNumber(Integer fileNumber) {
		this.fileNumber = fileNumber;
	}
	/**
	 * @return the fileName
	 */
	public String getFileName() {
		return fileName;
	}
	/**
	 * @param fileName the fileName to set
	 */
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	/**
	 * @return the data
	 */
	public byte[] getData() {
		return data;
	}
	/**
	 * @param data the data to set
	 */
	public void setData(byte[] data) {
		this.data = data;
	}
	/**
	 * @return the fileType
	 */
	public String getFileType() {
		return fileType;
	}
	/**
	 * @param fileType the fileType to set
	 */
	public void setFileType(String fileType) {
		this.fileType = fileType;
	}
	/**
	 * @return the fileMemory
	 */
	public Long getFileMemory() {
		return fileMemory;
	}
	/**
	 * @param fileMemory the fileMemory to set
	 */
	public void setFileMemory(Long fileMemory) {
		this.fileMemory = fileMemory;
	}
	/**
	 * @return the customerId
	 */
	public Long getCustomerId() {
		return customerId;
	}
	/**
	 * @param customerId the customerId to set
	 */
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
}
