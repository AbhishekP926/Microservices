/**
 * 
 */
package com.example.morgage.Customer.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.morgage.Customer.entities.DBFile;

/**
 * @author PendyalA
 *
 */
public interface FilesDao extends JpaRepository<DBFile, Long> {

}
