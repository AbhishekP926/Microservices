/**
 * 
 */
package com.example.morgage.NationalData.serviceimpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.morgage.NationalData.dao.NationDataCenterDao;
import com.example.morgage.NationalData.entity.CustomerData;
import com.example.morgage.NationalData.service.NationDataCenterService;

/**
 * @author PendyalA
 *
 */
@Service
public class NationalDataCenterServiceImpl implements NationDataCenterService  {

	@Autowired
	NationDataCenterDao repo;
	
	@Override
	public List<CustomerData> fetchAllUsersData(){
	      return repo.findAll();
	}
	
	@Override
	public CustomerData fetchUsersData(String pMobilenumber) {
		
	       return repo.findBymobileNumber(pMobilenumber);
	}

	@Override
	public CustomerData postUserData(CustomerData pCustomerData) {
		// TODO Auto-generated method stub
		return repo.save(pCustomerData);
	}
}   
