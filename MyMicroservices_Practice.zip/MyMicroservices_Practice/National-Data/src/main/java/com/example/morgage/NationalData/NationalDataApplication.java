package com.example.morgage.NationalData;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NationalDataApplication {

	public static void main(String[] args) {
		SpringApplication.run(NationalDataApplication.class, args);
	}

}
