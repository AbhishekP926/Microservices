/**
 * 
 */
package com.example.morgage.NationalData.entity;

import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 * @author PendyalA
 *
 */
@Entity
@Table(name="NATIONALDB_CUSTOMERDATA")
public class CustomerData {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long oid;
	private String mobileNumber;
	private String uniqueId;
	private String name;
	@Transient
	private int port;
	
	
	public void setPort(int port) {
		this.port = port;
	}
	@Embedded
	private CustomerAddress address;
	
	public CustomerData() {
		super();
	}
	/**
	 * @param oid
	 * @param mobileNumber
	 * @param uniqueId
	 * @param address
	 */
	public CustomerData(Long oid, String mobileNumber, String uniqueId, CustomerAddress address,String name) {
		super();
		this.oid = oid;
		this.mobileNumber = mobileNumber;
		this.uniqueId = uniqueId;
		this.address = address;
		this.name = name;
	}
	/**
	 * @return the oid
	 */
	public Long getOid() {
		return oid;
	}
	/**
	 * @param oid the oid to set
	 */
	public void setOid(Long oid) {
		this.oid = oid;
	}
	/**
	 * @return the mobileNumber
	 */
	public String getMobileNumber() {
		return mobileNumber;
	}
	/**
	 * @param mobileNumber the mobileNumber to set
	 */
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	/**
	 * @return the uniqueId
	 */
	public String getUniqueId() {
		return uniqueId;
	}
	/**
	 * @param uniqueId the uniqueId to set
	 */
	public void setUniqueId(String uniqueId) {
		this.uniqueId = uniqueId;
	}
	/**
	 * @return the address
	 */
	public CustomerAddress getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(CustomerAddress address) {
		this.address = address;
	}
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the port
	 */
	public int getPort() {
		return port;
	}
	/**
	 * @param port the port to set
	 */
	
}

