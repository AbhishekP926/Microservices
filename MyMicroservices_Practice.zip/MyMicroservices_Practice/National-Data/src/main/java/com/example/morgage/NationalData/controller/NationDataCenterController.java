/**
 * 
 */
package com.example.morgage.NationalData.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.morgage.NationalData.entity.CustomerData;
import com.example.morgage.NationalData.service.NationDataCenterService;

/**
 * @author PendyalA
 *
 */
@RestController
@RequestMapping("/ndb")
public class NationDataCenterController {

	@Autowired
	NationDataCenterService service;
	
	@Autowired
	private Environment env;
	
//	private String APPLICATION_PORT = env.getProperty("local.server.port");
	
	@GetMapping("/allusers")
	public List<CustomerData> fetchAllUsersData(){
		return service.fetchAllUsersData();
	}
	
	@GetMapping("/users/{mobilenumber}")
	public ResponseEntity<CustomerData> fetchUsersData(@PathVariable String mobilenumber){
		CustomerData customerData = service.fetchUsersData(mobilenumber);
//		customerData.setPort(Integer.parseInt(APPLICATION_PORT));
		return ResponseEntity.ok().body(customerData);
	}
	
	@PostMapping("/Users")
	public ResponseEntity<CustomerData> postUserData(@RequestBody CustomerData pCustomerData){
		
		CustomerData customerData    = service.postUserData(pCustomerData);
//		customerData.setPort(Integer.parseInt(APPLICATION_PORT));
		
		URI  location  = ServletUriComponentsBuilder.fromCurrentRequest().path("/{name}/{uniqueId}").buildAndExpand(customerData.getName(),customerData.getUniqueId()).toUri();
		
		return  ResponseEntity.created(location).body(customerData);
	} 
	

}
