/**
 * 
 */
package com.example.morgage.NationalData.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.morgage.NationalData.entity.CustomerData;

/**
 * @author PendyalA
 *
 */
@Repository
public interface NationDataCenterDao extends JpaRepository<CustomerData,Long> {

	CustomerData findBymobileNumber(String pMobilenumber);

}

