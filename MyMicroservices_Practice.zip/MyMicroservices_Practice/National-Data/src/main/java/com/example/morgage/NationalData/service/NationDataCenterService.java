/**
 * 
 */
package com.example.morgage.NationalData.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.example.morgage.NationalData.entity.CustomerData;

/**
 * @author PendyalA
 *
 */
@Service
public interface NationDataCenterService {

	public List<CustomerData> fetchAllUsersData();
	
	public CustomerData fetchUsersData(String mobilenumber);
	
	public CustomerData postUserData(CustomerData pCustomerData);
}
