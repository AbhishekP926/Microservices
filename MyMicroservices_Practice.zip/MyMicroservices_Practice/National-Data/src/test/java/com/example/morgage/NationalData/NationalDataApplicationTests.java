package com.example.morgage.NationalData;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NationalDataApplicationTests {

	@Test
	void contextLoads() {
	}

}
