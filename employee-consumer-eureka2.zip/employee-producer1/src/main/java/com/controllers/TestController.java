package com.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.model.Employee;

@RestController
public class TestController {

	@RequestMapping(value = "/employee", method = RequestMethod.GET,
			produces=MediaType.APPLICATION_JSON_VALUE)
	public Employee firstPage() {

		Employee emp = new Employee();
		emp.setName("emp1");
		emp.setDesignation("manager");
		emp.setEmpId("1");
		emp.setSalary(3000);

		return emp;
	}
	
	@RequestMapping(value = "/employeeList", method = RequestMethod.GET,
			produces={MediaType.APPLICATION_JSON_VALUE})
	public List<Employee> firstPage1() {

		Employee emp = new Employee();
		emp.setName("emp1");
		emp.setDesignation("manager");
		emp.setEmpId("1");
		emp.setSalary(3000);
		
		Employee emp1 = new Employee();
		emp.setName("emp12");
		emp.setDesignation("manager2");
		emp.setEmpId("12");
		emp.setSalary(30005);
		
		Employee emp2 = new Employee();
		emp.setName("emp13");
		emp.setDesignation("manager3");
		emp.setEmpId("13");
		emp.setSalary(30004);
		
		List<Employee> ll=new ArrayList<Employee>();
		ll.add(emp2);
		ll.add(emp1);
		
		ll.add(emp);

		return ll;
	}

}